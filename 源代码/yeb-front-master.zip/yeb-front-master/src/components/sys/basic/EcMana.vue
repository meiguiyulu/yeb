<template>
  <div>
    奖惩规则
  </div>
</template>
<script>
export default {
  name: "EcMana",
  data() {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>
