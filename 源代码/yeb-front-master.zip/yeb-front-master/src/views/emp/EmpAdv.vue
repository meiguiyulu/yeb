<template>
 <div>
   高级资料
 </div>
</template>

<script>
export default {
name: "EmpAdv",
  data () {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>
