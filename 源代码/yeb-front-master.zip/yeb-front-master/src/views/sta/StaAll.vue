<template>
 <div>
   综合信息统计
 </div>
</template>
<script>
export default {
name: "StaAll",
  data () {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>
