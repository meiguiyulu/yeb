<template>
 <div>
   员工积分统计
 </div>
</template>
<script>
export default {
name: "StaScore",
  data () {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>
