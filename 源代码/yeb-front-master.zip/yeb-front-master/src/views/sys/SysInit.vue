<template>
 <div>
   初始化数据库
 </div>
</template>
<script>
export default {
name: "SysInit",
  data () {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>
