<template>
  <div>
    系统管理
  </div>
</template>
<script>
export default {
  name: "SysConfig",
  data() {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>
