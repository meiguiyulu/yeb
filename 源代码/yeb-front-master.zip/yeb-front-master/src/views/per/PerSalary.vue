<template>
  <div>
    员工调薪
  </div>
</template>
<script>
export default {
  name: "PerSalary",
  data() {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>
