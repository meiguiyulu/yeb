<template>
  <div>
    员工调动
  </div>
</template>
<script>
export default {
  name: "PerMv",
  data() {
    return {}
  },
  methods: {}
}
</script>

<style scoped>

</style>
