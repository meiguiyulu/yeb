package com.xxxx.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xxxx.server.pojo.PoliticsStatus;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zhoubin
 */
public interface IPoliticsStatusService extends IService<PoliticsStatus> {

}
