package com.xxxx.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xxxx.server.pojo.SysMsg;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zhoubin
 */
public interface ISysMsgService extends IService<SysMsg> {

}
