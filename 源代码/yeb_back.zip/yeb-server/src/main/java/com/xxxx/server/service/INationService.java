package com.xxxx.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xxxx.server.pojo.Nation;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zhoubin
 */
public interface INationService extends IService<Nation> {

}
