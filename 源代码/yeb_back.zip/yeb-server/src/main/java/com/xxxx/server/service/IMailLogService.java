package com.xxxx.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xxxx.server.pojo.MailLog;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zhoubin
 */
public interface IMailLogService extends IService<MailLog> {

}
