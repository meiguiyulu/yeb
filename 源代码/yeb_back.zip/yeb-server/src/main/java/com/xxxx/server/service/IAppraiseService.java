package com.xxxx.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xxxx.server.pojo.Appraise;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zhoubin
 */
public interface IAppraiseService extends IService<Appraise> {

}
