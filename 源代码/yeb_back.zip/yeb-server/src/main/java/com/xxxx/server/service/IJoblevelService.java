package com.xxxx.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xxxx.server.pojo.Joblevel;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zhoubin
 */
public interface IJoblevelService extends IService<Joblevel> {

}
